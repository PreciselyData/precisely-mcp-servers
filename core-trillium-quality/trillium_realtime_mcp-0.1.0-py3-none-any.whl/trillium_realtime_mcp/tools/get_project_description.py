import json

from mcp import types as mcp_types

_DESCRIPTION = (
    "Return the operator-configured description for this MCP server instance "
    "(set via TRILLIUM_PROJECT_DESCRIPTION environment variable). "
    "Useful when multiple Trillium MCP servers are deployed side-by-side to help "
    "agents and clients identify which server handles which project or data domain. "
    "Returns an empty string if no description has been configured."
)


async def execute(description: str) -> mcp_types.CallToolResult:
    """Return the configured project description for this server instance."""
    return mcp_types.CallToolResult(
        content=[
            mcp_types.TextContent(
                type="text",
                text=json.dumps({"description": description}),
            )
        ],
        isError=False,
    )
