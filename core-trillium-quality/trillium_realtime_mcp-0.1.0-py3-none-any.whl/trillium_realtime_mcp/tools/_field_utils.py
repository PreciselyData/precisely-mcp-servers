from __future__ import annotations


def normalize_record_keys(
    record: dict[str, object],
    canonical_fields: list[str],
    context: str = "record",
) -> dict[str, object]:
    """Remap caller-supplied record keys to their canonical (project-defined) casing.

    Unrecognized keys are passed through unchanged so the caller's existing
    extra-keys validation can still catch and report them.

    Raises ValueError if two caller-supplied keys resolve to the same canonical
    field name (ambiguous normalization).
    """
    norm_map: dict[str, str] = {name.upper(): name for name in canonical_fields}
    seen: dict[str, str] = {}  # upper_key → original caller key
    result: dict[str, object] = {}

    for caller_key, value in record.items():
        upper = caller_key.upper()
        if upper in seen:
            canonical = norm_map.get(upper, upper)
            raise ValueError(
                f"Ambiguous field names in {context}: "
                f"{seen[upper]!r} and {caller_key!r} both resolve to {canonical!r}"
            )
        seen[upper] = caller_key
        canonical = norm_map.get(upper, caller_key)
        result[canonical] = value

    return result


def normalize_field_name(
    name: str,
    canonical_fields: list[str],
) -> str | None:
    """Resolve a single field name to its canonical form using case-insensitive matching.

    Returns the canonical field name if found, or None if no match.
    """
    upper = name.upper()
    for f in canonical_fields:
        if f.upper() == upper:
            return f
    return None


def normalize_output_fields(
    output_fields: list[str] | None,
    canonical_output_fields: list[str],
) -> list[str] | None:
    """Normalize a caller-supplied output_fields list to canonical casing.

    Unrecognized values are silently dropped. Returns None when the input is
    None or when all entries are unrecognized (semantics: return all fields).
    """
    if output_fields is None:
        return None
    norm_map: dict[str, str] = {f.upper(): f for f in canonical_output_fields}
    result = [norm_map[f.upper()] for f in output_fields if f.upper() in norm_map]
    return result if result else None
