from __future__ import annotations

import json
from typing import Optional

from mcp import types as mcp_types
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.tools.base import FuncMetadata, Tool
from mcp.server.fastmcp.utilities.func_metadata import ArgModelBase
from pydantic import ConfigDict, create_model

from trillium_realtime_mcp.models.project_definition import ErrorResponse, ProjectDefinition
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient
from trillium_realtime_mcp.tools._field_utils import normalize_field_name, normalize_output_fields, normalize_record_keys

_UNAVAILABLE_MSG = (
    "Service error [503]: reference_match is unavailable "
    "— project has no match fields configured"
)


def build_reference_match_schema(project: ProjectDefinition) -> dict:
    """Build JSON Schema for reference_match input."""
    field_props = {f.name: {"type": f.type} for f in project.match_input_fields}
    record_item_schema = {
        "type": "object",
        "description": (
            "Record fields. Field names are case-insensitive — "
            "any casing is accepted and normalized server-side."
        ),
        "properties": field_props,
        "additionalProperties": False,
    }
    return {
        "type": "object",
        "required": ["match_record", "records"],
        "additionalProperties": False,
        "properties": {
            "match_record": {
                **record_item_schema,
                "description": "The reference (master) record to match against.",
            },
            "records": {
                "type": "array",
                "description": "Candidate records to match against the reference record.",
                "minItems": 1,
                "items": record_item_schema,
            },
            "output_fields": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Optional list of match output field names to return. "
                    "Omit to return all match output fields. "
                    "Unrecognised entries are silently dropped; "
                    "if no entries are recognised, all match output fields are returned."
                ),
            },
            "name_form": {
                "type": "string",
                "description": "Name form for matching. Defaults to '1' if omitted.",
            },
            "match_level": {
                "type": "string",
                "description": "Match sensitivity level. Defaults to '1' if omitted.",
            },
            "user_key_field": {
                "type": "string",
                "description": (
                    "Optional field name whose value should be returned as MATCHER_USER_KEY. "
                    "Must be one of the fields present in the submitted records. "
                    "The server computes the 1-based wire offset from the sorted post-normalisation "
                    "canonical key set of the first record. "
                    "All candidate records must contain the same set of fields (case-insensitive); "
                    "runtime enforcement of this constraint is out of scope."
                ),
            },
        },
    }


async def execute(
    records: list[dict],
    match_record: dict,
    project: ProjectDefinition,
    client: TrilliumClient,
    output_fields: list[str] | None = None,
    name_form: str | None = None,
    match_level: str | None = None,
    user_key_field: str | None = None,
) -> mcp_types.CallToolResult:
    """Validate and forward a reference_match request."""
    if not project.match_input_fields:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=_UNAVAILABLE_MSG)],
            isError=True,
        )

    if not records:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(
                type="text", text="Validation error: records list must not be empty"
            )],
            isError=True,
        )

    if not match_record:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(
                type="text", text="Validation error: match_record is required"
            )],
            isError=True,
        )

    known_input = {f.name for f in project.match_input_fields}

    # Normalize match_record field keys to canonical project casing
    try:
        match_record = normalize_record_keys(
            match_record,
            [f.name for f in project.match_input_fields],
            context="match_record",
        )
    except ValueError as exc:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(exc))],
            isError=True,
        )

    # Normalize candidate record keys
    normalized_records: list[dict] = []
    for i, rec in enumerate(records):
        try:
            normalized_records.append(
                normalize_record_keys(
                    rec,
                    [f.name for f in project.match_input_fields],
                    context=f"records[{i}]",
                )
            )
        except ValueError as exc:
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(type="text", text=str(exc))],
                isError=True,
            )
    records = normalized_records

    # Validate match_record fields
    extra = set(match_record.keys()) - known_input
    if extra:
        label = ", ".join(sorted(extra))
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(
                type="text",
                text=f"Validation error: unknown field(s) in match_record: {label}",
            )],
            isError=True,
        )

    # Validate candidate record fields
    for i, rec in enumerate(records):
        extra = set(rec.keys()) - known_input
        if extra:
            label = ", ".join(sorted(extra))
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(
                    type="text",
                    text=f"Validation error: unknown field(s) in records[{i}]: {label}",
                )],
                isError=True,
            )

    # Normalize output_fields to canonical casing; unrecognized entries silently dropped
    output_fields = normalize_output_fields(
        output_fields, [f.name for f in project.match_output_fields]
    )

    # Compute 1-based wire offset from the sorted record keys
    input_key_offset = 0
    if user_key_field is not None:
        canonical_key = normalize_field_name(
            user_key_field, [f.name for f in project.match_input_fields]
        )
        if canonical_key is None:
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(
                    type="text",
                    text=f"Validation error: user_key_field {user_key_field!r} not found in project fields",
                )],
                isError=True,
            )
        sample = records[0] if records else {}
        sorted_keys = sorted(sample.keys())
        input_key_offset = sorted_keys.index(canonical_key) + 1

    try:
        result = await client.reference_match(
            records,
            match_record,
            output_fields=output_fields,
            name_form=name_form,
            match_level=match_level,
            input_key_offset=input_key_offset,
        )
    except ErrorResponse as e:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(e))],
            isError=True,
        )

    if not result:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text="No matches found")],
            isError=False,
        )
    return mcp_types.CallToolResult(
        content=[mcp_types.TextContent(type="text", text=json.dumps(result))],
        isError=False,
    )


def register_reference_match_tool(
    mcp: FastMCP,
    project: ProjectDefinition | None,
    client: TrilliumClient,
) -> None:
    """Register the reference_match tool on the FastMCP server."""
    if project is None:
        @mcp.tool()
        async def reference_match() -> mcp_types.CallToolResult:
            """Submit a reference record and candidates for reference matching."""
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(
                    type="text",
                    text="Service error [503]: Project metadata unavailable — schemas unavailable",
                )],
                isError=True,
            )
        return

    schema = build_reference_match_schema(project)

    class _Base(ArgModelBase):
        model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

        def model_dump_one_level(self) -> dict:
            result = super().model_dump_one_level()
            result.update(self.model_extra or {})
            return result

    arg_model = create_model(
        "ReferenceMatchArgs",
        __base__=_Base,
        match_record=(Optional[dict], None),
        records=(Optional[list], None),
        output_fields=(Optional[list], None),
        name_form=(Optional[str], None),
        match_level=(Optional[str], None),
        user_key_field=(Optional[str], None),
    )

    async def _handler(**kwargs: object) -> mcp_types.CallToolResult:
        match_record = dict(kwargs.get("match_record") or {})
        records = [dict(r) for r in (kwargs.get("records") or [])]
        output_fields = kwargs.get("output_fields")
        if isinstance(output_fields, list):
            output_fields = [str(f) for f in output_fields] or None
        else:
            output_fields = None
        name_form = kwargs.get("name_form") or None
        match_level = kwargs.get("match_level") or None
        return await execute(
            records,
            match_record,
            project,
            client,
            output_fields=output_fields,
            name_form=name_form,
            match_level=match_level,
            user_key_field=kwargs.get("user_key_field") or None,
        )

    fn_metadata = FuncMetadata(arg_model=arg_model, output_schema=None)
    tool = Tool(
        fn=_handler,
        name="reference_match",
        description="Submit a reference record and candidate records for reference matching.",
        parameters=schema,
        fn_metadata=fn_metadata,
        is_async=True,
        context_kwarg=None,
    )
    # TODO: Replace with FastMCP public add_tool() API once available.
    # FastMCP's add_tool() currently accepts callables only and cannot accept a pre-built
    # Tool object with a custom parameter schema. Direct _tool_manager access is the only
    # way to register a dynamically-generated JSON Schema without auto-generating one from
    # function introspection. Track: https://github.com/jlowin/fastmcp (update when resolved).
    mcp._tool_manager._tools["reference_match"] = tool
