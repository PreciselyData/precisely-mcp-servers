import json

from mcp import types as mcp_types

from trillium_realtime_mcp.models.project_definition import ErrorResponse
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient


async def execute(client: TrilliumClient) -> mcp_types.CallToolResult:
    """Call the backing service health endpoint and return status information."""
    try:
        result = await client.ping()
        return mcp_types.CallToolResult(
            content=[
                mcp_types.TextContent(
                    type="text",
                    text=json.dumps({"status": result.status, "latency_ms": result.latency_ms}),
                )
            ],
            isError=False,
        )
    except ErrorResponse as e:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(e))],
            isError=True,
        )
