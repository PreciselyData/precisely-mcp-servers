from __future__ import annotations

import json

from mcp import types as mcp_types
from mcp.server.fastmcp import FastMCP

from trillium_realtime_mcp.models.project_definition import ErrorResponse
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient

_DESCRIPTION = (
    "Retrieve request statistics for the server's configured web key (TRILLIUM_API_KEY). "
    "Returns the number of cleansing operations, matching operations, and the total across both, "
    "charged against the key as cumulative counts since the last server-side reset "
    "(no time-window filtering is available). "
    "Stats are scoped to the single configured web key; "
    "cross-key or aggregate user reporting is not supported by this API."
)


def register_request_stats_tool(mcp: FastMCP, client: TrilliumClient) -> None:
    @mcp.tool(description=_DESCRIPTION)
    async def get_request_stats() -> mcp_types.CallToolResult:
        try:
            stats = await client.get_request_stats()
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(type="text", text=json.dumps(stats.model_dump()))],
                isError=False,
            )
        except ErrorResponse as exc:
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(type="text", text=str(exc))],
                isError=True,
            )
