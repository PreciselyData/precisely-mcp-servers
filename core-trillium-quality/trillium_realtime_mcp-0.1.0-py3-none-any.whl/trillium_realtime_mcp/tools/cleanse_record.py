import json
from typing import Optional

from mcp import types as mcp_types
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.tools.base import FuncMetadata, Tool
from mcp.server.fastmcp.utilities.func_metadata import ArgModelBase
from pydantic import ConfigDict, create_model

from trillium_realtime_mcp.models.project_definition import ErrorResponse, ProjectDefinition
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient
from trillium_realtime_mcp.tools._field_utils import normalize_output_fields, normalize_record_keys

_JSON_TYPE_MAP: dict[str, type] = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
}


def build_cleanse_schema(project: ProjectDefinition) -> dict:
    """Build a JSON Schema dict from a project's input field definitions."""
    return {
        "type": "object",
        "description": (
            "Record fields. Field names are case-insensitive — "
            "any casing is accepted and normalized server-side."
        ),
        "properties": {
            field.name: {"type": field.type}
            for field in project.input_fields
        },
        "required": [
            field.name for field in project.input_fields if field.required
        ],
        "additionalProperties": False,
    }


def _build_permissive_arg_model(project: ProjectDefinition) -> type[ArgModelBase]:
    """Create a Pydantic arg model that accepts all project fields plus extras."""

    class _PermissiveBase(ArgModelBase):
        model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

        def model_dump_one_level(self) -> dict:
            result = super().model_dump_one_level()
            result.update(self.model_extra or {})
            return result

    optional_fields: dict = {}
    for field in project.input_fields:
        python_type = _JSON_TYPE_MAP.get(field.type, str)
        optional_fields[field.name] = (Optional[python_type], None)

    return create_model("CleanseArgs", __base__=_PermissiveBase, **optional_fields)


async def execute(
    record: dict,
    project: ProjectDefinition,
    client: TrilliumClient,
    output_fields: list[str] | None = None,
) -> mcp_types.CallToolResult:
    """Validate and forward a cleanse record request."""
    # Normalize record field keys to canonical project casing
    try:
        record = normalize_record_keys(
            record, [f.name for f in project.input_fields]
        )
    except ValueError as exc:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(exc))],
            isError=True,
        )

    # Normalize output_fields to canonical casing; unrecognized entries silently dropped
    output_fields = normalize_output_fields(
        output_fields, [f.name for f in project.output_fields]
    )

    known = {f.name for f in project.input_fields}
    required = {f.name for f in project.input_fields if f.required}

    # Reject unknown fields
    provided = set(record.keys())
    extra_keys = provided - known
    if extra_keys:
        label = ", ".join(sorted(extra_keys))
        return mcp_types.CallToolResult(
            content=[
                mcp_types.TextContent(
                    type="text",
                    text="Validation error: unknown field(s): " + label,
                )
            ],
            isError=True,
        )

    # Check required fields
    for field_name in required:
        if record.get(field_name) is None:
            return mcp_types.CallToolResult(
                content=[
                    mcp_types.TextContent(
                        type="text",
                        text="Validation error: required field "
                        + repr(field_name)
                        + " is missing",
                    )
                ],
                isError=True,
            )

    clean_record = {k: v for k, v in record.items() if v is not None}

    try:
        result = await client.cleanse(clean_record, output_fields=output_fields)
        return mcp_types.CallToolResult(
            content=[
                mcp_types.TextContent(type="text", text=json.dumps(result))
            ],
            isError=False,
        )
    except ErrorResponse as e:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(e))],
            isError=True,
        )


def register_cleanse_tool(
    mcp: FastMCP,
    project: ProjectDefinition | None,
    client: TrilliumClient,
) -> None:
    """Register the cleanse_record tool on the FastMCP server.

    If project is None the tool is registered but always returns an error.
    """
    if project is None:
        @mcp.tool()
        async def cleanse_record() -> mcp_types.CallToolResult:
            """Submit a data record for cleansing."""
            return mcp_types.CallToolResult(
                content=[
                    mcp_types.TextContent(
                        type="text",
                        text="Service error [503]: Project metadata unavailable — "
                        "schemas unavailable",
                    )
                ],
                isError=True,
            )

        return

    def _build_arg_schema(project: ProjectDefinition) -> dict:
        base = build_cleanse_schema(project)
        base["properties"]["output_fields"] = {
            "type": "array",
            "items": {"type": "string"},
            "description": (
                "Optional list of output field names to return. "
                "Omit to return all output fields. "
                "Unrecognised entries are silently dropped; "
                "if no entries are recognised, all output fields are returned."
            ),
        }
        return base

    arg_model = _build_permissive_arg_model(project)
    schema = _build_arg_schema(project)

    async def _handler(**kwargs: object) -> mcp_types.CallToolResult:
        output_fields = kwargs.pop("output_fields", None)  # type: ignore[assignment]
        if isinstance(output_fields, list):
            output_fields = [str(f) for f in output_fields] or None
        else:
            output_fields = None
        return await execute(dict(kwargs), project, client, output_fields=output_fields)

    fn_metadata = FuncMetadata(arg_model=arg_model, output_schema=None)
    tool = Tool(
        fn=_handler,
        name="cleanse_record",
        description="Submit a data record for cleansing.",
        parameters=schema,
        fn_metadata=fn_metadata,
        is_async=True,
        context_kwarg=None,
    )
    # TODO: Replace with FastMCP public add_tool() API once available.
    # FastMCP's add_tool() currently accepts callables only and cannot accept a pre-built
    # Tool object with a custom parameter schema. Direct _tool_manager access is the only
    # way to register a dynamically-generated JSON Schema without auto-generating one from
    # function introspection. Track: https://github.com/jlowin/fastmcp (update when resolved).
    mcp._tool_manager._tools["cleanse_record"] = tool
