import json

from mcp import types as mcp_types

from trillium_realtime_mcp.models.project_definition import ErrorResponse
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient


async def execute(client: TrilliumClient) -> mcp_types.CallToolResult:
    """Retrieve the project definition from the backing service."""
    try:
        project = await client.get_project_metadata()
        return mcp_types.CallToolResult(
            content=[
                mcp_types.TextContent(
                    type="text",
                    text=json.dumps(project.model_dump()),
                )
            ],
            isError=False,
        )
    except ErrorResponse as e:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(e))],
            isError=True,
        )
