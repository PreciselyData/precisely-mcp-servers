from __future__ import annotations

import json
from typing import Optional

from mcp import types as mcp_types
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.tools.base import FuncMetadata, Tool
from mcp.server.fastmcp.utilities.func_metadata import ArgModelBase
from pydantic import ConfigDict, create_model

from trillium_realtime_mcp.models.project_definition import ErrorResponse, ProjectDefinition
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient
from trillium_realtime_mcp.tools._field_utils import normalize_output_fields, normalize_record_keys

_UNAVAILABLE_MSG = (
    "Service error [503]: window_match is unavailable "
    "— project has no match fields configured"
)


def build_window_match_schema(project: ProjectDefinition) -> dict:
    """Build JSON Schema for window_match input."""
    field_props = {
        f.name: {"type": f.type}
        for f in project.match_input_fields
    }
    return {
        "type": "object",
        "required": ["records"],
        "additionalProperties": False,
        "properties": {
            "records": {
                "type": "array",
                "description": "One or more candidate records to match.",
                "minItems": 1,
                "items": {
                    "type": "object",
                    "description": (
                        "Record fields. Field names are case-insensitive — "
                        "any casing is accepted and normalized server-side."
                    ),
                    "properties": field_props,
                    "additionalProperties": False,
                },
            },
            "output_fields": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Optional list of match output field names to return. "
                    "Omit to return all match output fields. "
                    "Unrecognised entries are silently dropped; "
                    "if no entries are recognised, all match output fields are returned."
                ),
            },
        },
    }


async def execute(
    records: list[dict],
    project: ProjectDefinition,
    client: TrilliumClient,
    output_fields: list[str] | None = None,
) -> mcp_types.CallToolResult:
    """Validate and forward a window_match request."""
    if not project.match_input_fields:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=_UNAVAILABLE_MSG)],
            isError=True,
        )

    if not records:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(
                type="text", text="Validation error: records list must not be empty"
            )],
            isError=True,
        )

    known_input = {f.name for f in project.match_input_fields}

    # Normalize record field keys to canonical project casing
    normalized: list[dict] = []
    for i, rec in enumerate(records):
        try:
            normalized.append(
                normalize_record_keys(
                    rec,
                    [f.name for f in project.match_input_fields],
                    context=f"records[{i}]",
                )
            )
        except ValueError as exc:
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(type="text", text=str(exc))],
                isError=True,
            )
    records = normalized

    for i, rec in enumerate(records):
        extra = set(rec.keys()) - known_input
        if extra:
            label = ", ".join(sorted(extra))
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(
                    type="text",
                    text=f"Validation error: unknown field(s) in records[{i}]: {label}",
                )],
                isError=True,
            )

    # Normalize output_fields to canonical casing; unrecognized entries silently dropped
    output_fields = normalize_output_fields(
        output_fields, [f.name for f in project.match_output_fields]
    )

    try:
        result = await client.window_match(records, output_fields=output_fields)
    except ErrorResponse as e:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text=str(e))],
            isError=True,
        )

    if not result:
        return mcp_types.CallToolResult(
            content=[mcp_types.TextContent(type="text", text="No matches found")],
            isError=False,
        )
    return mcp_types.CallToolResult(
        content=[mcp_types.TextContent(type="text", text=json.dumps(result))],
        isError=False,
    )


def register_window_match_tool(
    mcp: FastMCP,
    project: ProjectDefinition | None,
    client: TrilliumClient,
) -> None:
    """Register the window_match tool on the FastMCP server."""
    if project is None:
        @mcp.tool()
        async def window_match() -> mcp_types.CallToolResult:
            """Submit one or more candidate records for window matching."""
            return mcp_types.CallToolResult(
                content=[mcp_types.TextContent(
                    type="text",
                    text="Service error [503]: Project metadata unavailable — schemas unavailable",
                )],
                isError=True,
            )
        return

    schema = build_window_match_schema(project)

    # Build a permissive arg model that accepts 'records' and 'output_fields'
    class _Base(ArgModelBase):
        model_config = ConfigDict(extra="allow", arbitrary_types_allowed=True)

        def model_dump_one_level(self) -> dict:
            result = super().model_dump_one_level()
            result.update(self.model_extra or {})
            return result

    arg_model = create_model(
        "WindowMatchArgs",
        __base__=_Base,
        records=(Optional[list], None),
        output_fields=(Optional[list], None),
    )

    async def _handler(**kwargs: object) -> mcp_types.CallToolResult:
        records = kwargs.get("records") or []
        output_fields = kwargs.get("output_fields")
        if isinstance(output_fields, list):
            output_fields = [str(f) for f in output_fields] or None
        else:
            output_fields = None
        return await execute(
            [dict(r) for r in records] if records else [],
            project,
            client,
            output_fields=output_fields,
        )

    fn_metadata = FuncMetadata(arg_model=arg_model, output_schema=None)
    tool = Tool(
        fn=_handler,
        name="window_match",
        description="Submit one or more candidate records for window matching.",
        parameters=schema,
        fn_metadata=fn_metadata,
        is_async=True,
        context_kwarg=None,
    )
    # TODO: Replace with FastMCP public add_tool() API once available.
    # FastMCP's add_tool() currently accepts callables only and cannot accept a pre-built
    # Tool object with a custom parameter schema. Direct _tool_manager access is the only
    # way to register a dynamically-generated JSON Schema without auto-generating one from
    # function introspection. Track: https://github.com/jlowin/fastmcp (update when resolved).
    mcp._tool_manager._tools["window_match"] = tool
