import asyncio
import os
import ssl as ssl_module
import sys
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from trillium_realtime_mcp.models.project_definition import ErrorResponse, ProjectDefinition
from trillium_realtime_mcp.stub.client_protocol import TrilliumClient
from trillium_realtime_mcp.stub.handler import StubClient
from trillium_realtime_mcp.stub.loader import load_stub_scenario
from trillium_realtime_mcp.tools import get_project_metadata as get_project_metadata_module
from trillium_realtime_mcp.tools import ping as ping_module
from trillium_realtime_mcp.tools import get_project_description as get_project_description_module
from trillium_realtime_mcp.tools.cleanse_record import register_cleanse_tool
from trillium_realtime_mcp.tools.window_match import register_window_match_tool
from trillium_realtime_mcp.tools.reference_match import register_reference_match_tool
from trillium_realtime_mcp.tools.get_request_stats import register_request_stats_tool


def create_server(client: TrilliumClient, project: ProjectDefinition | None = None, description: str = "") -> FastMCP:
    """Build and return a configured FastMCP server instance."""
    mcp = FastMCP("Trillium Realtime MCP")

    @mcp.tool()
    async def ping():
        """Verify that the backing service is reachable and responsive."""
        return await ping_module.execute(client)

    @mcp.tool()
    async def get_project_metadata():
        """Retrieve the project definition including input and output field schemas."""
        return await get_project_metadata_module.execute(client)

    @mcp.tool(description=get_project_description_module._DESCRIPTION)
    async def get_project_description():
        return await get_project_description_module.execute(description)

    register_cleanse_tool(mcp, project, client)

    register_window_match_tool(mcp, project, client)

    register_reference_match_tool(mcp, project, client)

    register_request_stats_tool(mcp, client)

    return mcp


def _build_ssl_verify(ca_bundle: str) -> ssl_module.SSLContext | bool:
    """Validate TRILLIUM_CA_BUNDLE and return an SSLContext or True (default verification)."""
    if not ca_bundle or not ca_bundle.strip():
        return True
    path = Path(ca_bundle)
    if not path.exists():
        print(f"Error: TRILLIUM_CA_BUNDLE path not found: {ca_bundle}", file=sys.stderr)
        sys.exit(1)
    try:
        if path.is_dir():
            ctx = ssl_module.create_default_context(capath=str(path))
        else:
            ctx = ssl_module.create_default_context(cafile=str(path))
    except ssl_module.SSLError as e:
        print(
            f"Error: TRILLIUM_CA_BUNDLE is not a valid CA bundle: {ca_bundle} \u2014 {e}",
            file=sys.stderr,
        )
        sys.exit(1)
    print(f"TLS: using custom CA bundle: {ca_bundle}", file=sys.stderr)
    return ctx


def resolve_client() -> tuple[TrilliumClient, ProjectDefinition | None, str]:
    """Read env vars, validate, and return the appropriate client, project definition, and description."""
    base_url = os.environ.get("TRILLIUM_BASE_URL")
    stub_file = os.environ.get("TRILLIUM_STUB_FILE")
    api_key = os.environ.get("TRILLIUM_API_KEY")
    description = os.environ.get("TRILLIUM_PROJECT_DESCRIPTION", "")

    # Validate API key
    if api_key is not None and not api_key.strip():
        print("Error: TRILLIUM_API_KEY is set but empty", file=sys.stderr)
        sys.exit(1)

    # Conflict check
    if base_url is not None and stub_file is not None:
        print(
            "Error: TRILLIUM_BASE_URL and TRILLIUM_STUB_FILE cannot both be set",
            file=sys.stderr,
        )
        sys.exit(1)

    # Neither set
    if base_url is None and stub_file is None:
        print(
            "Error: one of TRILLIUM_BASE_URL or TRILLIUM_STUB_FILE must be set",
            file=sys.stderr,
        )
        sys.exit(1)

    # Stub mode
    if stub_file is not None:
        scenario = load_stub_scenario()
        return StubClient(scenario), scenario.project, description

    # HTTP mode validation
    if not base_url or not base_url.strip():
        print("Error: TRILLIUM_BASE_URL is set but empty", file=sys.stderr)
        sys.exit(1)

    timeout_str = os.environ.get("TRILLIUM_REQUEST_TIMEOUT_SECONDS", "60")
    try:
        timeout = float(timeout_str)
    except ValueError:
        print(
            f"Error: TRILLIUM_REQUEST_TIMEOUT_SECONDS must be a number, got {timeout_str!r}",
            file=sys.stderr,
        )
        sys.exit(1)

    # Import here to avoid circular imports at module level
    from trillium_realtime_mcp.http.client import HttpClient

    ssl_verify = (
        _build_ssl_verify(os.environ.get("TRILLIUM_CA_BUNDLE", ""))
        if base_url.strip().lower().startswith("https://")
        else True
    )

    http_client = HttpClient(
        base_url=base_url.strip(),
        api_key=api_key if api_key else None,
        timeout=timeout,
        ssl_verify=ssl_verify,
    )

    # Async startup: auto-discover project name, then fetch and validate project definition
    async def _startup() -> ProjectDefinition:
        await http_client.open()
        try:
            try:
                project_name = await http_client.get_active_project()
            except ErrorResponse as e:
                print(f"Error: failed to discover active project: {e}", file=sys.stderr)
                sys.exit(1)

            if not project_name:
                print(
                    "Error: /activeProjects returned no active project — "
                    "verify that a project is deployed on the Trillium service",
                    file=sys.stderr,
                )
                sys.exit(1)

            print(f"Active project auto-discovered: {project_name}", file=sys.stderr)

            try:
                project = await http_client.get_project_metadata()
            except ErrorResponse as e:
                print(f"Error: failed to fetch project metadata: {e}", file=sys.stderr)
                sys.exit(1)

            if not project.input_fields:
                print(
                    f"Error: project {project_name!r} returned an empty input field list",
                    file=sys.stderr,
                )
                sys.exit(1)

            if not project.output_fields:
                print(
                    f"Error: project {project_name!r} returned an empty output field list",
                    file=sys.stderr,
                )
                sys.exit(1)

            return project
        finally:
            await http_client.close()

    project = asyncio.run(_startup())
    return http_client, project, description


async def _main() -> None:
    """Single async entrypoint — runs startup, MCP server loop, and shutdown in one event loop."""
    base_url = os.environ.get("TRILLIUM_BASE_URL")
    stub_file = os.environ.get("TRILLIUM_STUB_FILE")
    api_key = os.environ.get("TRILLIUM_API_KEY")
    description = os.environ.get("TRILLIUM_PROJECT_DESCRIPTION", "")

    # Validate API key
    if api_key is not None and not api_key.strip():
        print("Error: TRILLIUM_API_KEY is set but empty", file=sys.stderr)
        sys.exit(1)

    # Conflict check
    if base_url is not None and stub_file is not None:
        print(
            "Error: TRILLIUM_BASE_URL and TRILLIUM_STUB_FILE cannot both be set",
            file=sys.stderr,
        )
        sys.exit(1)

    # Neither set
    if base_url is None and stub_file is None:
        print(
            "Error: one of TRILLIUM_BASE_URL or TRILLIUM_STUB_FILE must be set",
            file=sys.stderr,
        )
        sys.exit(1)

    # Stub mode — no open/close needed
    if stub_file is not None:
        scenario = load_stub_scenario()
        client: TrilliumClient = StubClient(scenario)
        server = create_server(client, scenario.project, description)
        await server.run_stdio_async()
        return

    # HTTP mode validation
    if not base_url or not base_url.strip():
        print("Error: TRILLIUM_BASE_URL is set but empty", file=sys.stderr)
        sys.exit(1)

    timeout_str = os.environ.get("TRILLIUM_REQUEST_TIMEOUT_SECONDS", "60")
    try:
        timeout = float(timeout_str)
    except ValueError:
        print(
            f"Error: TRILLIUM_REQUEST_TIMEOUT_SECONDS must be a number, got {timeout_str!r}",
            file=sys.stderr,
        )
        sys.exit(1)

    from trillium_realtime_mcp.http.client import HttpClient

    ssl_verify = (
        _build_ssl_verify(os.environ.get("TRILLIUM_CA_BUNDLE", ""))
        if base_url.strip().lower().startswith("https://")
        else True
    )

    http_client = HttpClient(
        base_url=base_url.strip(),
        api_key=api_key if api_key else None,
        timeout=timeout,
        ssl_verify=ssl_verify,
    )
    await http_client.open()
    try:
        try:
            project_name = await http_client.get_active_project()
        except ErrorResponse as e:
            print(f"Error: failed to discover active project: {e}", file=sys.stderr)
            sys.exit(1)

        if not project_name:
            print(
                "Error: /activeProjects returned no active project — "
                "verify that a project is deployed on the Trillium service",
                file=sys.stderr,
            )
            sys.exit(1)

        print(f"Active project auto-discovered: {project_name}", file=sys.stderr)

        try:
            project = await http_client.get_project_metadata()
        except ErrorResponse as e:
            print(f"Error: failed to fetch project metadata: {e}", file=sys.stderr)
            sys.exit(1)

        if not project.input_fields:
            print(
                f"Error: project {project_name!r} returned an empty input field list",
                file=sys.stderr,
            )
            sys.exit(1)

        if not project.output_fields:
            print(
                f"Error: project {project_name!r} returned an empty output field list",
                file=sys.stderr,
            )
            sys.exit(1)

        server = create_server(http_client, project, description)
        await server.run_stdio_async()
    finally:
        await http_client.close()


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
