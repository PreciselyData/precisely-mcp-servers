from __future__ import annotations

import ssl as ssl_module
import time
from typing import Any, NoReturn

import httpx

from trillium_realtime_mcp.models.project_definition import (
    ErrorResponse,
    FieldDefinition,
    PingResult,
    ProjectDefinition,
    WebKeyStats,
)


class HttpClient:
    def __init__(
        self,
        base_url: str,
        api_key: str | None,
        timeout: float,
        project_name: str = "",
        ssl_verify: ssl_module.SSLContext | bool = True,
    ) -> None:
        # Normalise: strip trailing slash, append the fixed REST path prefix
        root = base_url.rstrip("/")
        self._base = f"{root}/TrilliumSOAP/REST"
        self._project_name = project_name
        self._api_key = api_key
        self._timeout = timeout
        self._ssl_verify = ssl_verify
        self._cached_project: ProjectDefinition | None = None
        self._http: httpx.AsyncClient | None = None

    async def open(self) -> None:
        self._http = httpx.AsyncClient(timeout=httpx.Timeout(self._timeout), verify=self._ssl_verify)

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    # ------------------------------------------------------------------
    # Public protocol methods
    # ------------------------------------------------------------------

    async def ping(self) -> PingResult:
        if self._http is None:
            await self.open()
        url = f"{self._base}/ping"
        start = time.monotonic()
        try:
            response = await self._http.get(url, params=self._params())
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        elapsed_ms = int((time.monotonic() - start) * 1000)
        if response.status_code >= 400:
            self._handle_error(response)
        return PingResult(status="healthy", latency_ms=elapsed_ms)

    async def get_active_project(self) -> str:
        """Call GET /activeProjects and return the trimmed project name."""
        if self._http is None:
            await self.open()
        url = f"{self._base}/activeProjects"
        try:
            response = await self._http.get(url, params=self._params())
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        if response.status_code >= 400:
            raise ErrorResponse(
                response.status_code,
                f"/activeProjects returned HTTP {response.status_code} — "
                "check TRILLIUM_BASE_URL and TRILLIUM_API_KEY",
            )
        try:
            data = response.json()
            name = data.get("ProjectName", "").strip()
        except Exception:
            raise ErrorResponse(502, f"Non-JSON response from service (status {response.status_code})")
        if name:
            self._project_name = name
        return name

    async def get_project_metadata(self) -> ProjectDefinition:
        input_fields = await self._fetch_field_list("cleanseInputFields")
        output_fields = await self._fetch_field_list("cleanseOutputFields")
        match_input_fields = await self._fetch_field_list("matchInputFields")
        match_output_fields = await self._fetch_field_list("matchOutputFields")
        project = ProjectDefinition(
            name=self._project_name,
            input_fields=self._fields_from_names(input_fields),
            output_fields=self._fields_from_names(output_fields),
            match_input_fields=self._fields_from_names(match_input_fields),
            match_output_fields=self._fields_from_names(match_output_fields),
        )
        self._cached_project = project
        return project

    async def cleanse(
        self,
        record: dict[str, Any],
        output_fields: list[str] | None = None,
    ) -> dict[str, Any]:
        if self._http is None:
            await self.open()
        if output_fields is None and self._cached_project is None:
            raise ErrorResponse(
                503,
                "output_fields not specified and project metadata not yet loaded "
                "\u2014 call get_project_metadata() first",
            )
        effective_output = (
            output_fields
            if output_fields
            else [f.name for f in (self._cached_project.output_fields if self._cached_project else [])]
        )
        body = {
            "outputFields": effective_output,
            "record": {"trilliumFieldValues": self._to_wire(record)},
        }
        url = f"{self._base}/cleanse"
        try:
            response = await self._http.post(
                url,
                params=self._params(projectName=self._project_name),
                json=body,
            )
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        if response.status_code >= 400:
            self._handle_error(response)
        try:
            data = response.json()
        except Exception:
            raise ErrorResponse(502, f"Non-JSON response from service (status {response.status_code})")
        return self._from_wire(data.get("trilliumFieldValues", []))

    async def window_match(
        self,
        records: list[dict[str, Any]],
        output_fields: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        if self._http is None:
            await self.open()
        if output_fields is None and self._cached_project is None:
            raise ErrorResponse(
                503,
                "output_fields not specified and project metadata not yet loaded "
                "\u2014 call get_project_metadata() first",
            )
        effective_output = (
            output_fields
            if output_fields
            else [f.name for f in (self._cached_project.match_output_fields if self._cached_project else [])]
        )
        body = {
            "outputFields": effective_output,
            "records": [{"trilliumFieldValues": self._to_wire(r)} for r in records],
        }
        url = f"{self._base}/matchWindow"
        try:
            response = await self._http.post(
                url,
                params=self._params(projectName=self._project_name),
                json=body,
            )
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        if response.status_code >= 400:
            self._handle_error(response)
        try:
            data = response.json()
        except Exception:
            raise ErrorResponse(502, f"Non-JSON response from service (status {response.status_code})")
        if not data:
            return []
        return [self._from_wire(rec.get("trilliumFieldValues", [])) for rec in data]

    async def reference_match(
        self,
        records: list[dict[str, Any]],
        match_record: dict[str, Any],
        output_fields: list[str] | None = None,
        name_form: str | None = None,
        match_level: str | None = None,
        input_key_offset: int = 0,
    ) -> list[dict[str, Any]]:
        if self._http is None:
            await self.open()
        body: dict[str, Any] = {
            "records": [{"trilliumFieldValues": self._to_wire(r)} for r in records],
            "matchRecord": {"trilliumFieldValues": self._to_wire(match_record)},
        }
        params: dict[str, Any] = self._params(projectName=self._project_name)
        params["inputKeyOffset"] = str(input_key_offset)
        params["nameForm"] = name_form if name_form is not None else "1"
        params["matchLevel"] = match_level if match_level is not None else "1"
        url = f"{self._base}/matchReference"
        try:
            response = await self._http.post(url, params=params, json=body)
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        if response.status_code >= 400:
            self._handle_error(response)
        try:
            data = response.json()
        except Exception:
            raise ErrorResponse(502, f"Non-JSON response from service (status {response.status_code})")
        if not data:
            return []
        return [self._from_wire(rec.get("trilliumFieldValues", [])) for rec in data]

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _params(self, **extra: str) -> dict[str, str]:
        params: dict[str, str] = {}
        if self._api_key:
            params["webKey"] = self._api_key
        params.update(extra)
        return params

    @staticmethod
    def _to_wire(record: dict[str, Any]) -> list[dict[str, Any]]:
        return [{"trilliumField": k, "trilliumValue": record[k]} for k in sorted(record)]

    @staticmethod
    def _from_wire(fields: list[dict[str, Any]]) -> dict[str, Any]:
        return {f["trilliumField"]: f["trilliumValue"] for f in fields}

    @staticmethod
    def _fields_from_names(names: list[str]) -> list[FieldDefinition]:
        # The Trillium REST API does not return field type or required-field metadata;
        # all fields default to type="string" and required=False.
        return [FieldDefinition(name=n, type="string", required=False) for n in names]

    def _handle_error(self, response: httpx.Response) -> NoReturn:
        try:
            payload = response.json()
            description = str(payload)
        except Exception:
            description = response.text[:200]
        raise ErrorResponse(response.status_code, description)

    async def get_request_stats(self) -> WebKeyStats:
        if self._api_key is None:
            raise ErrorResponse(503, "get_request_stats requires a webKey — set TRILLIUM_API_KEY")
        if self._http is None:
            await self.open()
        url = f"{self._base}/webKeyStatistics"
        try:
            response = await self._http.get(url, params=self._params())
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        if response.status_code >= 400:
            self._handle_error(response)
        try:
            data = response.json()
        except Exception:
            raise ErrorResponse(502, f"Non-JSON response from service (status {response.status_code})")
        if "ERROR" in data:
            raise ErrorResponse(403, data["ERROR"])
        try:
            return WebKeyStats(
                cleansing_count=int(data["Number of Cleansing"]),
                matching_count=int(data["Number of Matching"]),
                total=int(data["Total"]),
            )
        except (KeyError, ValueError) as exc:
            raise ErrorResponse(502, f"Unexpected response from webKeyStatistics: {exc}")

    async def _fetch_field_list(self, endpoint: str) -> list[str]:
        if self._http is None:
            await self.open()
        url = f"{self._base}/{endpoint}"
        try:
            response = await self._http.post(
                url,
                params=self._params(projectName=self._project_name),
            )
        except httpx.ConnectError:
            raise ErrorResponse(503, "Service unreachable")
        except httpx.TimeoutException:
            raise ErrorResponse(504, f"Request timed out after {self._timeout} seconds")
        if response.status_code >= 400:
            self._handle_error(response)
        try:
            data = response.json()
        except Exception:
            raise ErrorResponse(502, f"Non-JSON response from service (status {response.status_code})")
        # Trillium returns HTTP 200 with a single-element error message (containing
        # spaces) when the project is not deployed or otherwise unavailable.
        # Valid field names are identifiers and never contain whitespace.
        if isinstance(data, list) and data and isinstance(data[0], str) and " " in data[0]:
            raise ErrorResponse(502, data[0])
        return data
