from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from trillium_realtime_mcp.models.project_definition import PingResult, ProjectDefinition, WebKeyStats


@runtime_checkable
class TrilliumClient(Protocol):
    async def ping(self) -> PingResult: ...

    async def get_project_metadata(self) -> ProjectDefinition: ...

    async def cleanse(self, record: dict[str, Any], output_fields: list[str] | None = None) -> dict[str, Any]: ...

    async def window_match(
        self,
        records: list[dict[str, Any]],
        output_fields: list[str] | None = None,
    ) -> list[dict[str, Any]]: ...

    async def reference_match(
        self,
        records: list[dict[str, Any]],
        match_record: dict[str, Any],
        output_fields: list[str] | None = None,
        name_form: str | None = None,
        match_level: str | None = None,
        input_key_offset: int = 0,
    ) -> list[dict[str, Any]]: ...

    async def get_request_stats(self) -> WebKeyStats: ...
