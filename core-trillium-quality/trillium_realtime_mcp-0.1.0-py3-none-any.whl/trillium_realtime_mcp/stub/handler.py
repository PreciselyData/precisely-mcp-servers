from __future__ import annotations

from typing import Any

from trillium_realtime_mcp.models.project_definition import ErrorResponse, PingResult, ProjectDefinition, WebKeyStats
from trillium_realtime_mcp.models.stub_config import StubScenario


class StubClient:
    def __init__(self, scenario: StubScenario) -> None:
        self._scenario = scenario

    async def ping(self) -> PingResult:
        pr = self._scenario.ping_response
        if pr.is_error():
            raise pr.to_error()
        return pr.to_ping_result()

    async def get_project_metadata(self) -> ProjectDefinition:
        project = self._scenario.project
        if project is None:
            raise ErrorResponse(http_status=503, error="Project metadata unavailable")
        return project

    async def cleanse(self, record: dict[str, Any], output_fields: list[str] | None = None) -> dict[str, Any]:
        cr = self._scenario.cleanse_response
        if cr.is_error():
            raise cr.to_error()
        return dict(cr.fields or {})

    async def window_match(
        self,
        records: list[dict[str, Any]],
        output_fields: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        mr = self._scenario.window_match_response
        if mr.is_error():
            raise mr.to_error()
        return list(mr.records or [])

    async def reference_match(
        self,
        records: list[dict[str, Any]],
        match_record: dict[str, Any],
        output_fields: list[str] | None = None,
        name_form: str | None = None,
        match_level: str | None = None,
        input_key_offset: int = 0,
    ) -> list[dict[str, Any]]:
        mr = self._scenario.reference_match_response
        if mr.is_error():
            raise mr.to_error()
        return list(mr.records or [])

    async def get_request_stats(self) -> WebKeyStats:
        sr = self._scenario.request_stats_response
        if sr.is_error():
            raise sr.to_error()
        return sr.to_stats()
