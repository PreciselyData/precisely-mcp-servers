from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from trillium_realtime_mcp.models.stub_config import StubConfig, StubScenario


def load_stub_scenario() -> StubScenario:
    stub_file = os.environ.get("TRILLIUM_STUB_FILE", "").strip()
    if not stub_file:
        sys.exit("TRILLIUM_STUB_FILE environment variable is not set. Cannot start server.")

    path = Path(stub_file)
    if not path.exists():
        sys.exit(f"Stub file not found: {stub_file}")

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        sys.exit(f"Invalid JSON in stub file '{stub_file}': {exc}")

    try:
        config = StubConfig(
            scenarios={
                name: StubScenario.from_raw(data)
                for name, data in raw.get("scenarios", {}).items()
            }
        )
    except Exception as exc:
        sys.exit(f"Invalid stub config structure in '{stub_file}': {exc}")

    scenario_name = os.environ.get("TRILLIUM_STUB_SCENARIO", "healthy").strip()
    if scenario_name not in config.scenarios:
        available = ", ".join(sorted(config.scenarios.keys()))
        sys.exit(
            f"Scenario '{scenario_name}' not found in stub file '{stub_file}'. "
            f"Available scenarios: {available}"
        )

    return config.scenarios[scenario_name]
