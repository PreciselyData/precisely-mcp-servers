from __future__ import annotations

from typing import Any

from pydantic import BaseModel, model_validator

from trillium_realtime_mcp.models.project_definition import ProjectDefinition, PingResult, ErrorResponse, WebKeyStats


class PingResponseStub(BaseModel):
    # Either healthy: {status, latency_ms} or error: {http_status, error}
    status: str | None = None
    latency_ms: int | None = None
    http_status: int | None = None
    error: str | None = None

    def is_error(self) -> bool:
        return self.http_status is not None

    def to_ping_result(self) -> PingResult:
        if self.status is None or self.latency_ms is None:
            raise ValueError("to_ping_result() called on an error stub — status and latency_ms are None")
        return PingResult(status=self.status, latency_ms=self.latency_ms)

    def to_error(self) -> ErrorResponse:
        if self.http_status is None or self.error is None:
            raise ValueError("to_error() called on a non-error stub — http_status and error are None")
        return ErrorResponse(http_status=self.http_status, error=self.error)


class CleanseResponseStub(BaseModel):
    # Either a dict of output fields, or an error {http_status, error}
    http_status: int | None = None
    error: str | None = None
    fields: dict[str, Any] | None = None

    @model_validator(mode="before")
    @classmethod
    def _normalize_raw(cls, v: Any) -> Any:
        """Normalize raw dicts so {field: val} format populates `fields`."""
        if isinstance(v, dict) and "http_status" not in v and "fields" not in v:
            # Raw output fields dict — wrap it
            return {"fields": {k: val for k, val in v.items()}}
        return v

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> "CleanseResponseStub":
        if "http_status" in raw:
            return cls(http_status=raw["http_status"], error=raw.get("error"))
        return cls(fields={k: v for k, v in raw.items()})

    def is_error(self) -> bool:
        return self.http_status is not None

    def to_error(self) -> ErrorResponse:
        if self.http_status is None:
            raise ValueError("to_error() called on a non-error CleanseResponseStub — http_status is None")
        return ErrorResponse(http_status=self.http_status, error=self.error or "Unknown error")


class MatchResponseStub(BaseModel):
    http_status: int | None = None
    error: str | None = None
    records: list[dict[str, Any]] | None = None

    def is_error(self) -> bool:
        return self.http_status is not None

    def to_error(self) -> ErrorResponse:
        if self.http_status is None:
            raise ValueError("to_error() called on a non-error MatchResponseStub — http_status is None")
        return ErrorResponse(http_status=self.http_status, error=self.error or "Unknown error")

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> "MatchResponseStub":
        if "http_status" in raw:
            return cls(http_status=raw["http_status"], error=raw.get("error"))
        return cls(records=raw.get("records", []))


class RequestStatsStub(BaseModel):
    http_status: int | None = None
    error: str | None = None
    cleansing_count: int = 0
    matching_count: int = 0
    total: int = 0

    def is_error(self) -> bool:
        return self.http_status is not None

    def to_error(self) -> ErrorResponse:
        if self.http_status is None:
            raise ValueError("to_error() called on a non-error RequestStatsStub — http_status is None")
        return ErrorResponse(http_status=self.http_status, error=self.error or "Unknown error")

    def to_stats(self) -> WebKeyStats:
        return WebKeyStats(
            cleansing_count=self.cleansing_count,
            matching_count=self.matching_count,
            total=self.total,
        )


class StubScenario(BaseModel):
    project: ProjectDefinition | None
    ping_response: PingResponseStub
    cleanse_response: CleanseResponseStub
    window_match_response: MatchResponseStub = MatchResponseStub(records=[])
    reference_match_response: MatchResponseStub = MatchResponseStub(records=[])
    request_stats_response: RequestStatsStub = RequestStatsStub()

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> "StubScenario":
        return cls(
            project=ProjectDefinition(**raw["project"]) if raw.get("project") else None,
            ping_response=PingResponseStub(**raw["ping_response"]),
            cleanse_response=CleanseResponseStub.from_raw(raw["cleanse_response"]),
            window_match_response=MatchResponseStub.from_raw(raw["window_match_response"]) if raw.get("window_match_response") else MatchResponseStub(records=[]),
            reference_match_response=MatchResponseStub.from_raw(raw["reference_match_response"]) if raw.get("reference_match_response") else MatchResponseStub(records=[]),
            request_stats_response=RequestStatsStub(**raw["request_stats_response"]) if raw.get("request_stats_response") else RequestStatsStub(),
        )


class StubConfig(BaseModel):
    scenarios: dict[str, StubScenario]

    @model_validator(mode="after")
    def scenarios_non_empty(self) -> "StubConfig":
        if not self.scenarios:
            raise ValueError("Stub config must contain at least one scenario")
        return self
