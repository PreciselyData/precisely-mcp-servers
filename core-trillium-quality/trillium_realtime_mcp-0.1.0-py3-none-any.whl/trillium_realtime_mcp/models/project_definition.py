from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, field_validator


class FieldDefinition(BaseModel):
    name: str
    type: Literal["string", "integer", "number", "boolean"]
    required: bool = False

    @field_validator("name")
    @classmethod
    def name_no_whitespace(cls, v: str) -> str:
        if not v or v != v.strip() or " " in v:
            raise ValueError("Field name must be non-empty and contain no whitespace")
        return v


class ProjectDefinition(BaseModel):
    name: str
    input_fields: list[FieldDefinition]
    output_fields: list[FieldDefinition]
    match_input_fields: list[FieldDefinition] = []
    match_output_fields: list[FieldDefinition] = []

    @field_validator("name")
    @classmethod
    def name_non_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Project name must be non-empty")
        return v

    @field_validator("input_fields", "output_fields", "match_input_fields", "match_output_fields")
    @classmethod
    def unique_field_names(cls, fields: list[FieldDefinition]) -> list[FieldDefinition]:
        names = [f.name for f in fields]
        if len(names) != len(set(names)):
            raise ValueError("Field names must be unique")
        return fields


class PingResult(BaseModel):
    status: str
    latency_ms: int


class WebKeyStats(BaseModel):
    cleansing_count: int
    matching_count: int
    total: int


class ErrorResponse(Exception):
    def __init__(self, http_status: int, error: str) -> None:
        self.http_status = http_status
        self.error = error
        super().__init__(str(self))

    def __str__(self) -> str:
        label = "Client error" if 400 <= self.http_status <= 499 else "Service error"
        return f"{label} [{self.http_status}]: {self.error}"
